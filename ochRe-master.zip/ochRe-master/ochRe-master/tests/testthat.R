library(testthat)
library(ochRe)

test_check("ochRe")
